
# Cafe Pikkuli — Website

React + Vite site for Cafe Pikkuli (Patna). Pages: Home, Menu, Order, Gallery, Visit (Google Map).

## Run locally
```bash
npm install
npm run dev
```
Open the printed local URL (e.g. http://localhost:5173).

## Build
```bash
npm run build
```
Deploy the `dist/` folder to Netlify or Vercel.
