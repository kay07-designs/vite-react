
import React from 'react'
import ReactDOM from 'react-dom/client'
import CafePikkuliSite from './CafePikkuliSite'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <CafePikkuliSite />
  </React.StrictMode>
)
